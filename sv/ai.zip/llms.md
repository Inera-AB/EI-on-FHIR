# inera.ei.engagementindex#0.1.0: EI-on-FHIR: FHIR-API för engagemangsindex(sv)

## Pages

* [Hem](index.md)
* [Testning och validering](testing.md)
* [Om](about.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Användningsfall](use-cases.md)
* [API](api.md)
* [Synk till eHM:s patientindex](ehm-sync.md)
* [Säkerhet och loggning](security.md)
* [Versionshistorik](version-history.md)
* [Engagemangsposten](engagement.md)
* [Öppna frågor](open-issues.md)
* [Informationsunderlag](information-basis.md)
* [CapabilityStatement](capabilitystatement.md)
* [Nedladdningar](downloads.md)

## Resources

### CodeSystems

* [Kodsystem för kategorier inom tjänstedomän](CodeSystem-IneraEngagementCategoryCodeSystem.md)
* [Kodsystem för hämtningsprotokoll](CodeSystem-IneraRetrievalProtocolCodeSystem.md)
* [Kodsystem för tjänstedomäner](CodeSystem-IneraServiceDomainCodeSystem.md)

### ValueSets

* [Kategorier inom tjänstedomän](ValueSet-IneraEngagementCategoryValueSet.md)
* [Status för engagemangsposter](ValueSet-IneraEngagementStatusValueSet.md)
* [Hämtningsprotokoll](ValueSet-IneraRetrievalProtocolValueSet.md)
* [Tjänstedomäner](ValueSet-IneraServiceDomainValueSet.md)

### Resource Profiles

* [Engagemangspost](StructureDefinition-IneraEngagement.md)

### Extensions

* [Logisk adress](StructureDefinition-LogicalAddress.md)
* [Senaste innehåll](StructureDefinition-MostRecentContent.md)
* [Ägare](StructureDefinition-Owner.md)
* [Källsystem](StructureDefinition-SourceSystem.md)

### CapabilityStatements

* [EI-on-FHIR server](CapabilityStatement-IneraEngagementIndexServer.md)

### ImplementationGuides

* [EI-on-FHIR: FHIR-API för engagemangsindex](ImplementationGuide-inera.ei.engagementindex.md)

### SearchParameters

* [Sökparameter logical-address](SearchParameter-DocumentReference-logical-address.md)
* [Sökparameter source-system](SearchParameter-DocumentReference-source-system.md)

### Examples

* [SokresultatForPatient (Bundle)](Bundle-SokresultatForPatient.md)
* [EngagemangspostAktuell (DocumentReference)](DocumentReference-EngagemangspostAktuell.md)
* [EngagemangspostBorttagen (DocumentReference)](DocumentReference-EngagemangspostBorttagen.md)
* [EngagemangspostFhir (DocumentReference)](DocumentReference-EngagemangspostFhir.md)
* [EngagemangspostKallsystemSomPuA (DocumentReference)](DocumentReference-EngagemangspostKallsystemSomPuA.md)
