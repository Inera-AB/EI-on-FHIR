# inera.ei.engagementindex#0.1.0: FHIR-baserat engagemangsindex (FHIR-EI)(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Stöd för producenter](producer-support.md)
* [Prenumeration](subscriptions.md)
* [Testning och validering](testing.md)
* [Förväntade svar](expected-responses.md)
* [CapabilityStatement](capabilitystatement.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Indexposten](information-model.md)
* [Användningsfall](use-cases.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Versionshistorik](version-history.md)
* [Samexistens med eHM:s patientindex](ehm-coexistence.md)
* [Inledning](introduction.md)
* [Kodverk för tjänster och informationsmängder](information-sets.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Öppna frågor](open-issues.md)
* [Händelsemodell och övergång](event-model.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Spärr, loggning och behörighet](security.md)

## Resources

### CodeSystems

* [Kodsystem för orsaker till avregistrering](CodeSystem-IneraDeregistrationReasonCodeSystem.md)
* [Kodsystem för kategorier inom tjänstedomän](CodeSystem-IneraEngagementCategoryCodeSystem.md)
* [Kodsystem för registreringsstatus](CodeSystem-IneraIndexRegistrationStatusCodeSystem.md)
* [Kodsystem för tjänstedomäner](CodeSystem-IneraServiceDomainCodeSystem.md)

### ValueSets

* [Orsaker till avregistrering](ValueSet-IneraDeregistrationReasonValueSet.md)
* [Kategorier inom tjänstedomän](ValueSet-IneraEngagementCategoryValueSet.md)
* [Registreringsstatus för indexposter](ValueSet-IneraIndexRegistrationStatusValueSet.md)
* [Tjänstedomäner](ValueSet-IneraServiceDomainValueSet.md)

### Resource Profiles

* [Indexpost (FHIR-EI)](StructureDefinition-IneraIndexEntry.md)
* [Prenumeration på indexposter (FHIR-EI)](StructureDefinition-IneraIndexSubscription.md)

### Extensions

* [Vårdenhet](StructureDefinition-CareUnit.md)
* [Innehållets senaste ändring](StructureDefinition-ContentLastUpdated.md)
* [Orsak till avregistrering](StructureDefinition-DeregistrationReason.md)
* [Logisk adress](StructureDefinition-LogicalAddress.md)
* [Registrerande producent](StructureDefinition-RegisteringProducer.md)
* [Registreringsstatus](StructureDefinition-RegistrationStatus.md)
* [Producentens endpoint](StructureDefinition-SourceEndpoint.md)
* [Källsystem](StructureDefinition-SourceSystem.md)

### CapabilityStatements

* [FHIR-EI server](CapabilityStatement-IneraIndexServer.md)

### ImplementationGuides

* [FHIR-baserat engagemangsindex (FHIR-EI)](ImplementationGuide-inera.ei.engagementindex.md)

### SearchParameters

* [Sök på innehållets senaste ändring](SearchParameter-DocumentReference-content-last-updated.md)
* [Sök på producentens endpoint](SearchParameter-DocumentReference-source-endpoint.md)

### SubscriptionTopics

* [Indexpost ändrad](SubscriptionTopic-indexpost-andrad.md)

### Examples

* [RegistreringTransaction (Bundle)](Bundle-RegistreringTransaction.md)
* [SokresultatForPatient (Bundle)](Bundle-SokresultatForPatient.md)
* [IndexpostEjForPatient (DocumentReference)](DocumentReference-IndexpostEjForPatient.md)
* [IndexpostFhirProducent (DocumentReference)](DocumentReference-IndexpostFhirProducent.md)
* [IndexpostFranAdapter (DocumentReference)](DocumentReference-IndexpostFranAdapter.md)
* [IndexpostIndragen (DocumentReference)](DocumentReference-IndexpostIndragen.md)
* [PrenumerationForPatient (Subscription)](Subscription-PrenumerationForPatient.md)
