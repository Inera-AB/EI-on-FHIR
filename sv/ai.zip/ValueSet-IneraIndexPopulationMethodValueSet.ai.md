# Försörjningssätt - FHIR-baserat engagemangsindex (FHIR-EI) v0.1.0

## ValueSet: Försörjningssätt 

 **References** 

* [Indexpost (FHIR-EI)](StructureDefinition-IneraIndexEntry.md)

### Logisk definition (CLD)

 

### Expansion

-------

 [Beskrivning av ovanstående tabell(er)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "IneraIndexPopulationMethodValueSet",
  "url" : "https://fhir.inera.se/ig/engagementindex/ValueSet/IneraIndexPopulationMethodValueSet",
  "identifier" : [{
    "value" : "IneraIndexPopulationMethodValueSet"
  }],
  "version" : "0.1.0",
  "name" : "IneraIndexPopulationMethodValueSet",
  "title" : "Försörjningssätt",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-26",
  "publisher" : "Inera AB",
  "contact" : [{
    "name" : "Inera AB",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.inera.se"
    }]
  }],
  "description" : "Alla försörjningssätt för indexposter.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "SE",
      "display" : "Sweden"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraIndexPopulationMethodCodeSystem"
    }]
  }
}

```
