# Sökresultat för en patient - EI-on-FHIR: FHIR-API för engagemangsindex v0.1.0

## Exempel Bundle: Sökresultat för en patient



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "SokresultatForPatient",
  "type" : "searchset",
  "total" : 3,
  "link" : [{
    "relation" : "self",
    "url" : "https://ei.example.org/fhir/DocumentReference?subject:identifier=http://electronichealth.se/identifier/personnummer|191212121212"
  }],
  "entry" : [{
    "fullUrl" : "https://ei.example.org/fhir/DocumentReference/EngagemangspostAktuell",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "EngagemangspostAktuell",
      "meta" : {
        "lastUpdated" : "2026-11-02T14:32:10+01:00",
        "profile" : ["https://fhir.inera.se/ig/engagementindex/StructureDefinition/IneraEngagement"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_EngagemangspostAktuell\"> </a><p class=\"res-header-id\"><b>Genererad berättande text: DocumentReference EngagemangspostAktuell</b></p><a name=\"EngagemangspostAktuell\"> </a><a name=\"hcEngagemangspostAktuell\"> </a><div style=\"display: inline-block; background-color: #fbffeb; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Senast uppdaterad: 2026-11-02 14:32:10+0100</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-IneraEngagement.html\">Engagemangspost</a></p></div><p><b>Källsystem</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-SYS1</p><p><b>Ägare</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-EI00</p><p><b>Logisk adress</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-VG01</p><p><b>Senaste innehåll</b>: 2026-11-02 14:30:00+0100</p><p><b>identifier</b>: 7f3c2a10-5b1e-4c8e-9f7a-2d6b8e4a1c33</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Koder:{https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraServiceDomainCodeSystem riv:clinicalprocess:healthcond:description}\">riv:clinicalprocess:healthcond:description</span></p><p><b>category</b>: <span title=\"Koder:{https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraEngagementCategoryCodeSystem voo}\">voo</span></p><p><b>subject</b>: Identifier: <code>http://electronichealth.se/identifier/personnummer</code>/191212121212</p><p><b>date</b>: 2025-03-11 09:15:00+0100</p><p><b>custodian</b>: Identifier: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-VG01</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td></tr><tr><td style=\"display: none\">*</td><td>application/xml</td></tr></table><h3>Profiles</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"CodeSystem-IneraRetrievalProtocolCodeSystem.html#IneraRetrievalProtocolCodeSystem-riv-ta\">Kodsystem för hämtningsprotokoll: riv-ta</a> (RIV-TA)</td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/SourceSystem",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-SYS1"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/Owner",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-EI00"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/LogicalAddress",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-VG01"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/MostRecentContent",
        "valueDateTime" : "2026-11-02T14:30:00+01:00"
      }],
      "identifier" : [{
        "value" : "7f3c2a10-5b1e-4c8e-9f7a-2d6b8e4a1c33"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraServiceDomainCodeSystem",
          "code" : "riv:clinicalprocess:healthcond:description"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraEngagementCategoryCodeSystem",
          "code" : "voo"
        }]
      }],
      "subject" : {
        "identifier" : {
          "system" : "http://electronichealth.se/identifier/personnummer",
          "value" : "191212121212"
        }
      },
      "date" : "2025-03-11T09:15:00+01:00",
      "custodian" : {
        "identifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-VG01"
        }
      },
      "content" : [{
        "attachment" : {
          "contentType" : "application/xml"
        },
        "profile" : [{
          "valueCoding" : {
            "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraRetrievalProtocolCodeSystem",
            "code" : "riv-ta"
          }
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://ei.example.org/fhir/DocumentReference/EngagemangspostKallsystemSomPuA",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "EngagemangspostKallsystemSomPuA",
      "meta" : {
        "lastUpdated" : "2026-10-28T08:01:44+01:00",
        "profile" : ["https://fhir.inera.se/ig/engagementindex/StructureDefinition/IneraEngagement"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_EngagemangspostKallsystemSomPuA\"> </a><p class=\"res-header-id\"><b>Genererad berättande text: DocumentReference EngagemangspostKallsystemSomPuA</b></p><a name=\"EngagemangspostKallsystemSomPuA\"> </a><a name=\"hcEngagemangspostKallsystemSomPuA\"> </a><div style=\"display: inline-block; background-color: #fbffeb; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Senast uppdaterad: 2026-10-28 08:01:44+0100</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-IneraEngagement.html\">Engagemangspost</a></p></div><p><b>Källsystem</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-SYS2</p><p><b>Ägare</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-EI00</p><p><b>Logisk adress</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-VE02</p><p><b>identifier</b>: BOI-2024-000118</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Koder:{https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraServiceDomainCodeSystem riv:clinicalprocess:activityprescription:actoutcome}\">riv:clinicalprocess:activityprescription:actoutcome</span></p><p><b>subject</b>: Identifier: <code>http://electronichealth.se/identifier/personnummer</code>/191212121212</p><p><b>date</b>: 2024-06-03 10:20:00+0200</p><p><b>custodian</b>: Identifier: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-SYS2</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td></tr><tr><td style=\"display: none\">*</td><td>application/xml</td></tr></table><h3>Profiles</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"CodeSystem-IneraRetrievalProtocolCodeSystem.html#IneraRetrievalProtocolCodeSystem-riv-ta\">Kodsystem för hämtningsprotokoll: riv-ta</a> (RIV-TA)</td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/SourceSystem",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-SYS2"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/Owner",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-EI00"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/LogicalAddress",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-VE02"
        }
      }],
      "identifier" : [{
        "value" : "BOI-2024-000118"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraServiceDomainCodeSystem",
          "code" : "riv:clinicalprocess:activityprescription:actoutcome"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://electronichealth.se/identifier/personnummer",
          "value" : "191212121212"
        }
      },
      "date" : "2024-06-03T10:20:00+02:00",
      "custodian" : {
        "identifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-SYS2"
        }
      },
      "content" : [{
        "attachment" : {
          "contentType" : "application/xml"
        },
        "profile" : [{
          "valueCoding" : {
            "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraRetrievalProtocolCodeSystem",
            "code" : "riv-ta"
          }
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://ei.example.org/fhir/DocumentReference/EngagemangspostFhir",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "EngagemangspostFhir",
      "meta" : {
        "lastUpdated" : "2026-11-12T09:41:27+01:00",
        "profile" : ["https://fhir.inera.se/ig/engagementindex/StructureDefinition/IneraEngagement"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_EngagemangspostFhir\"> </a><p class=\"res-header-id\"><b>Genererad berättande text: DocumentReference EngagemangspostFhir</b></p><a name=\"EngagemangspostFhir\"> </a><a name=\"hcEngagemangspostFhir\"> </a><div style=\"display: inline-block; background-color: #fbffeb; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Senast uppdaterad: 2026-11-12 09:41:27+0100</p><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-IneraEngagement.html\">Engagemangspost</a></p></div><p><b>Källsystem</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-SYS1</p><p><b>Ägare</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-EIF0</p><p><b>Logisk adress</b>: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-VG01</p><p><b>Senaste innehåll</b>: 2026-11-12 09:40:00+0100</p><p><b>identifier</b>: c2d8e6f1-3a47-4b0e-9e21-5f8a7d3b6c04</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Koder:{https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraServiceDomainCodeSystem riv:clinicalprocess:healthcond:description}\">riv:clinicalprocess:healthcond:description</span></p><p><b>subject</b>: Identifier: <code>http://electronichealth.se/identifier/personnummer</code>/191212121212</p><p><b>date</b>: 2026-11-12 09:41:27+0100</p><p><b>custodian</b>: Identifier: <code>urn:oid:1.2.752.29.4.19</code>/SE0000000000-VG01</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>application/fhir+json</td><td><a href=\"https://fhir.vg01.example.org/fhir\">https://fhir.vg01.example.org/fhir</a></td></tr></table><h3>Profiles</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"CodeSystem-IneraRetrievalProtocolCodeSystem.html#IneraRetrievalProtocolCodeSystem-fhir\">Kodsystem för hämtningsprotokoll: fhir</a> (FHIR)</td></tr></table></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/SourceSystem",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-SYS1"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/Owner",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-EIF0"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/LogicalAddress",
        "valueIdentifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-VG01"
        }
      },
      {
        "url" : "https://fhir.inera.se/ig/engagementindex/StructureDefinition/MostRecentContent",
        "valueDateTime" : "2026-11-12T09:40:00+01:00"
      }],
      "identifier" : [{
        "value" : "c2d8e6f1-3a47-4b0e-9e21-5f8a7d3b6c04"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraServiceDomainCodeSystem",
          "code" : "riv:clinicalprocess:healthcond:description"
        }]
      },
      "subject" : {
        "identifier" : {
          "system" : "http://electronichealth.se/identifier/personnummer",
          "value" : "191212121212"
        }
      },
      "date" : "2026-11-12T09:41:27+01:00",
      "custodian" : {
        "identifier" : {
          "system" : "urn:oid:1.2.752.29.4.19",
          "value" : "SE0000000000-VG01"
        }
      },
      "content" : [{
        "attachment" : {
          "contentType" : "application/fhir+json",
          "url" : "https://fhir.vg01.example.org/fhir"
        },
        "profile" : [{
          "valueCoding" : {
            "system" : "https://fhir.inera.se/ig/engagementindex/CodeSystem/IneraRetrievalProtocolCodeSystem",
            "code" : "fhir"
          }
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
