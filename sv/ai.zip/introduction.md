# Inledning - FHIR-baserat engagemangsindex (FHIR-EI) v0.1.0

## Inledning

Detta är beskrivningen av FHIR-baserat engagemangsindex (FHIR-EI). IG:n är en kravspecifikation för parter som registrerar indexposter i, söker i eller prenumererar på FHIR-EI, och för tjänster som tillämpar indexprofilen. Parterna ska följa både de maskintolkbara reglerna i profilerna och de regler som uttrycks i text i denna IG.

-------

### Begrepp

FHIR-EI är ett rikt index av pekare. Det ska klara minst det dagens engagemangsindex klarar, och kunna samexistera med eHM:s tunna patientindex: antingen härleds det tunna indexet ur det rika, eller så fylls det rika utifrån det tunna.

| | |
| :--- | :--- |
| Indexpost | En pekare: patient × endpoint × tjänst, med de informationsmängder som finns och tidpunkt för senaste innehåll. Profil:[Indexpost](StructureDefinition-IneraIndexEntry.md) |
| Tjänst | En IG; motsvarar tjänstedomän i dagens modell |
| Informationsmängd | En profil eller resurs inom en tjänst; motsvarar kategori i dagens modell |
| Tillämpning | En tjänsts profil av den gemensamma indexprofilen, som bestämmer vad indexet svarar på för just den tjänsten. Se[Indexposten](information-model.md) |
| Endpoint | Producentens åtkomstpunkt, registrerad i tjänstekatalogen |
| Logisk adress | Den adress en RIV-TA-konsument anger mot tjänsteplattformen. I tjänstekatalogen är den en organisations HSA-id |
| Producent | Källsystem som håller informationen och exponerar den via en endpoint |
| Försörjning | Hur en tjänsts indexposter fylls och hålls aktuella: producentregistrering, Inera-försörjd cache eller spegling av dagens engagemangsindex. Se[Försörjning av indexet](population.md) |
| Registrerande part | System som skriver indexposter: en producent, en indexeringsagent, lokaliseringstjänsten eller övergångsadaptern. Identifieras med sin endpoint i tjänstekatalogen |
| Indexeringsagent | Komponent som prenumererar på tjänsternas topics hos producenternas FHIR-servrar och registrerar indexposter på producenternas vägnar |
| Lokaliseringstjänst | Ineras komponent som fyller indexet som en cache, utifrån eHM:s patientindex och riktade frågor till källorna |
| Konsument | Tjänst som söker i eller prenumererar på indexet, till exempel NPÖ och 1177 |
| Systemkonsument | Konsument som läser i systemkontext: prenumererar, stämmer av, gör massuttag eller håller en lokal kopia av innehåll aktuell |
| Användarkontext | Åtkomstläge där anropet görs för en namngiven användare och bär användarens anspråk. FHIR-EI prövar spärr, samtycke och syfte och loggar per användare. Se[Spärr, loggning och behörighet](security.md) |
| Systemkontext | Åtkomstläge utan användare. FHIR-EI prövar systemets behörighet, och det mottagande systemet prövar per användare när informationen visas |
| Indexkärna | Den del av FHIR-EI som lagrar indexposterna och sköter skrivning, livscykel, händelselogg, prenumeration, avstämning och massuttag. Se[Roller och ansvar](roles-and-responsibilities.md) |
| Åtkomstlager | Den del av FHIR-EI som tar emot sökning och läsning i användarkontext och prövar spärr, samtycke, syfte, fullmakt och säkerhetsetiketter |
| Tunt index | eHM:s patientindex kopplat till NDI |

-------

### Arkitekturprinciper

1. **Pekare, inte innehåll.**Indexet svarar på var och när, aldrig vad. Profilen förbjuder de element i DocumentReference som skulle beskriva eller bära journalinnehåll.
1. **Minst lika god förmåga som idag.**Det gäller aktualitet, leveransgarantier, borttag och återhämtning.
1. **Registrera en gång.**Vårdgivarna ska inte behöva registrera samma vårdrelation två gånger. Indexposten bär det som behövs för att härleda ett tunt index, och indexet kan också fyllas utifrån ett tunt index.
1. **Övergång utan krav på producenterna.**Befintliga uppdateringar till engagemangsindex mappas in, så att källsystem kan gå över till FHIR i egen takt.
1. **Indexet är självt skyddsvärd information.**Att en patient har en post hos en viss vårdenhet är en uppgift om patienten. Komponenten tillämpar därför spärr, loggning och filtrering.
1. **Profilering enligt Ineras tre-lagersmodell, ovanpå svenska basprofiler.**I denna version bygger profilen direkt på FHIR:s basresurser; se[Öppna frågor](open-issues.md).
1. **Neutral försörjning.**Konsumentkontraktet är detsamma oavsett hur en tjänsts indexposter fylls. Försörjningen är ett val per tjänst; se[Försörjning av indexet](population.md).
1. **Två åtkomstlägen.**Varje operation sker i användarkontext eller i systemkontext. Prövning per användare kräver en användare: i användarkontext görs den i FHIR-EI, i systemkontext av det mottagande systemet när informationen visas. Se[Spärr, loggning och behörighet](security.md).

-------

### Varför DocumentReference

Indexposten definieras i en gemensam logisk modell och representeras i FHIR R5 som en profilerad `DocumentReference`. Det är samma mönster som NHS NRL och IHE MHD. I R5 har DocumentReference breddats till att referera innehåll av alla slag, inte bara dokument.

Tre begrepp hålls isär:

| | | |
| :--- | :--- | :--- |
| Vårdepisod | Klinisk information hos producenten | Ingår inte |
| Indexpost | Uppgiften att information finns tillgänglig hos en producent | Representeras med[indexprofilen](StructureDefinition-IneraIndexEntry.md) |
| Innehåll | Själva journalinformationen | Hämtas från producentens endpoint efter att indexet pekat ut den |

