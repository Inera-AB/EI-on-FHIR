# Indexposten - FHIR-baserat engagemangsindex (FHIR-EI) v0.1.0

## Indexposten

Indexposten är en pekare: den anger att en producent, via en endpoint, har information om en patient inom en tjänst. Vem som har skrivit posten påverkar inte vad den betyder; se [Försörjning av indexet](population.md). Posten representeras med profilen [Indexpost](StructureDefinition-IneraIndexEntry.md) på R5 `DocumentReference`. Hur varje element motsvarar dagens engagemangsindex beskrivs under [Mappning till profiler](mappings.md).

### Granularitet

Det finns en post per patient × endpoint × tjänst. En tjänst är en IG och motsvarar tjänstedomän i dagens modell. En post kan bära flera informationsmängder. Tidpunkten för senaste ändring gäller hela posten. En informationsmängd som behöver en egen tidpunkt bryts ut till en egen tjänst.

### Registrerande part, endpoint och logisk adress

Den registrerande partens identitet är dess endpoint i tjänstekatalogen. FHIR-EI binder den autentiserade klienten till en Endpoint där, och postens [registeringProducer](StructureDefinition-RegisteringProducer.md) är en absolut referens till den endpointen. Samma URL är partens namnrymd i `identifier.system`, så att FHIR-EI kan kontrollera namnrymden utan ett eget register.

| | | | |
| :--- | :--- | :--- | :--- |
| Direktansluten FHIR-producent | Producentens endpoint | Samma endpoint | Utelämnas |
| Indexeringsagent | Producentens endpoint; agenten skriver med producentens identitet | Samma endpoint | Utelämnas |
| Lokaliseringstjänsten | Lokaliseringstjänstens egen endpoint | Källans endpoint i tjänstekatalogen, uppslagen via vårdgivaren i eHM:s patientindex | När källans endpoint adresseras med logisk adress |
| Övergångsadaptern | Adapterns egen endpoint | Endpoint enligt adapterns adressregister, t.ex. tjänsteplattformens endpoint för tjänstekontraktet | Logisk adress från dagens engagemangsindex |

En endpoint i tjänstekatalogen kan delas av många logiska adresser, till exempel tjänsteplattformens adress för ett tjänstekontrakt. Posten bär därför den [logiska adressen](StructureDefinition-LogicalAddress.md) separat när endpointen adresseras med logisk adress. I tjänstekatalogen är den logiska adressen en organisations HSA-id, så konsumenten kan slå upp den där.

När den registrerande parten inte är källan själv bär posten också [källsystemet](StructureDefinition-SourceSystem.md): källsystemet från dagens engagemangsindex vid spegling, eller journalsystemet från eHM:s patientindex vid Inera-försörjd cache.

Vårdgivaren i `custodian` anges med HSA-id eller organisationsnummer (`urn:oid:2.5.4.97`). eHM:s patientindex är nycklat på organisationsnummer, och tjänstekatalogen har båda på den juridiska personen. [Vårdenheten](StructureDefinition-CareUnit.md) anges när den är känd; den kan saknas när indexet fylls utifrån eHM:s patientindex.

### Tillämpning per tjänst

Vad indexet svarar på bestäms per tjänst: bara var det finns information, eller också vilka informationsmängder som finns och hur aktuella de är. Varje tjänst publicerar sin tillämpning som en profil av den gemensamma indexprofilen, i tjänstens IG. Därmed hålls semantiken ihop även när tjänsterna använder indexet olika.

| | | |
| :--- | :--- | :--- |
| Patient, tjänst, endpoint, registrerande part, vårdgivare | Obligatoriska | Inget |
| Vårdenhet | 0..* | Om den är obligatorisk. Försörjning utifrån eHM:s patientindex känner bara vårdgivaren |
| Informationsmängder | 0..* | Om de anges, och vilka värden som är tillåtna |
| Innehållets senaste ändring | 0..1 | Om den är obligatorisk, och vad som räknas som ändring |
| Status och livscykel | Obligatoriska | Inget |

En tillämpning i en tjänsts IG kan se ut så här. Tjänstens IG har denna IG som beroende.

```
Profile: LakemedelIndexEntry
Parent: https://fhir.inera.se/ig/engagementindex/StructureDefinition/IneraIndexEntry
* type.coding[implementationGuide].code = "<läkemedels-IG:ns canonical>"
* content.profile 1..*
* extension[contentLastUpdated] 1..1

```

En konsument känner igen indexposter på `meta.profile`.

#### Uppdateringsregler per tjänst

Tillämpningen bestämmer vad som räknas som en ändring, och den regeln ska vara maskinläsbar. Varje tjänst publicerar därför, utöver tillämpningsprofilen:

| | |
| :--- | :--- |
| En`SubscriptionTopic`per informationsmängd | Vilka ändringar i tjänstens innehållsresurser som räknas:`resourceTrigger`med`supportedInteraction`,`queryCriteria`och`fhirPathCriteria`. Till exempel att en Observation skapas eller går till`final` |
| Extensionen`obligation`i tillämpningsprofilen | Vilka element den registrerande parten ska fylla i |

`contentLastUpdated` är tidpunkten för den senaste händelse som uppfyller tjänstens topic. Samma topics driver indexeringsagenten och lokaliseringstjänstens prenumerationer; se [Försörjning av indexet](population.md).

#### Ändamål per tjänst

Tjänstens IG beskriver också hur tjänsten använder indexet: vilka konsumenter som läser och i vilket åtkomstläge, för vilket ändamål, och vad en systemkonsument sparar. Se [Rättslig grund och ändamål](legal-basis.md).

#### Tillämpningsprofilen och FHIR-version

Tillämpningsprofilen har indexprofilen som förälder och är därför en R5-profil. En tjänst vars IG är R4 publicerar sin tillämpning i ett separat R5-paket och anger sina topics med canonical, som i Subscriptions Backport.

### Tidpunkter

| | | |
| :--- | :--- | :--- |
| Innehållets senaste ändring | När det kliniska innehållet i källsystemet senast ändrades, enligt källan: producentens registrering, källans svar på en riktad fråga eller mostRecentContent i dagens engagemangsindex | Extension[contentLastUpdated](StructureDefinition-ContentLastUpdated.md) |
| Postens senaste ändring | När indexposten senast ändrades i FHIR-EI. Sätts av servern | `meta.lastUpdated`,`_history` |
| Mottagningstid | När FHIR-EI senast tog emot en rapport om posten | Loggas för drift och avstämning, inte sökbar |

En uppdatering av posten ändrar inte `contentLastUpdated` om innehållet är oförändrat.

### Livscykel

| | | | |
| :--- | :--- | :--- | :--- |
| Registrerad: informationen finns tillgänglig | `current` | `active` | Ja |
| Indragen: posten har dragits tillbaka (avslutat engagemang, gallring, eller källan uppger att informationen inte längre finns) | `superseded` | `withdrawn` | Nej; syns vid explicit statusfilter, ändringssökning och export |
| Felregistrerad: posten skulle aldrig ha funnits | `entered-in-error` | `entered-in-error` | Som indragen |

`DocumentReference.status` har en obligatorisk bindning till `current | superseded | entered-in-error` och kan inte utökas med egna koder. Den exakta semantiken bärs därför av extensionen `registrationStatus`. En generisk FHIR-konsument som inte förstår extensionen ser ändå på basvärdet att posten inte längre är aktuell. Profilens invarianter håller basvärdet och extensionen i takt.

`withdrawn` är valt framför `unavailable`, eftersom det uttrycker en avsiktlig och bestående handling. `unavailable` kan läsas som ett tillfälligt driftavbrott, och det ska indexet inte uttrycka.

Orsaken anges i [deregistrationReason](StructureDefinition-DeregistrationReason.md), som finns om och endast om posten inte är registrerad. En indragen post ligger kvar som gravsten under gravstenarnas lagringstid och rensas sedan fysiskt. Se [Händelsemodell och övergång](event-model.md).

### Exempel

* [Registrerad indexpost från en FHIR-producent](DocumentReference-IndexpostFhirProducent.md)
* [Indexpost fylld av lokaliseringstjänsten](DocumentReference-IndexpostFranLokaliseringstjanst.md)
* [Indexpost speglad av övergångsadaptern](DocumentReference-IndexpostFranAdapter.md)
* [Indragen indexpost](DocumentReference-IndexpostIndragen.md)

